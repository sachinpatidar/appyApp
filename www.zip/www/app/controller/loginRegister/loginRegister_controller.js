﻿angular.module('loginRegister.module.controller', []).controller('loginRegister.controller', function ($scope, $ionicPopup, $state, $ionicLoading, $rootScope) {


})